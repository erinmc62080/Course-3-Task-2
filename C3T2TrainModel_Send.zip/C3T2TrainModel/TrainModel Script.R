#importing caret and readr to start training model
library(caret)
library(readr)
#import complete responses dataset !!remember to use quotes when calling dataset!!!
completeresponses <-read.csv("CompleteResponses.csv")
#this is the dataset that will be used to test c50 and RandomForest classifiers
#check structure of data 
str(completeresponses)
#7 variables/all in numerical and integer format
summary(completeresponses)
attributes(completeresponses)
names(completeresponses)
#the only names I would want to change would be elevel to education and zipcode to region
names(completeresponses)<-c("salary","age","education","car","region","credit","brand")
names(completeresponses)
#will start to plot some of my attributes 
hist(completeresponses$age)
#minimum age is 20/max age is 80. 20 yr old demographic appears to be highest frequency, 80 yr old demographic least
hist(completeresponses$region)
hist(completeresponses$salary)
summary(completeresponses)
plot(completeresponses$age, completeresponses$education)
plot(completeresponses$salary, completeresponses$brand)
plot(completeresponses$age, completeresponses$brand)
#scatter plot did not tell me much 
qqnorm(completeresponses$age)
#qqnorm is not helpful to me right now 
#checking correlation 
cor.test(completeresponses$age, completeresponses$brand)
cor.test(completeresponses$salary, completeresponses$brand)
#model building begins here - will install the packages I need first 
library(tidyverse)
install.packages('tidyverse')
install.packages('xgboost')
#set my seed 
set.seed(123)
#I am going to use the full dataset to start, and skip using only 20% of data 
#defining 75/25 split of data for train and test 
inTraining <-createDataPartition(completeresponses$brand, p=.75, list = FALSE)
training <-completeresponses[inTraining,]
testing <-completeresponses[-inTraining,]
#setting up 10-fold cross validation 
fitControl <-trainControl(method = "repeatedcv", number = 10, repeats = 1)
#create model 
gbm.mod <-train(brand~., data = training, method = "gbm", trControl = fitControl, tuneLength = 1)
gbmod <-train(brand~., data = training, method = "gbm", trControl=fitControl, tuneLength = 1)
str(completeresponses)
str(CompleteResponses_New)
CompleteResponses_New$brand <-as.factor(CompleteResponses_New$brand)
str(CompleteResponses_New)
#changed brand to factor for classification model - let's see if that works 
#set my seed 
set.seed(123)
inTraining <-createDataPartition(CompleteResponses_New$brand, p=.75, list = FALSE)
training <-CompleteResponses_New[inTraining,] 
testing <-CompleteResponses_New[-inTraining,]
fitControl <-trainControl(method = "repeatedcv", number = 10, repeats = 1)
gbmod <-train(brand~., data = training, method = "gbm", trControl=fitControl, tuneLength = 1)
gbmod
varImp(gbmod)
varImp(gbmod, conditionall = TRUE)
library(gbm)
varImp(gbmod)
gbmodImp <- varImp(gbmod, scale = FALSE)
gbmodImp
plot(gbmodImp, top = 5)
#creating model 2 c50
library(c50)
install.packages('C50')
#repeating pipeline used for GBM
#set my seed 
set.seed(123)
#again, using full dataset 
#use createDataPartition for my train and test sets 
inTrainingC <-createDataPartition(CompleteResponses_New$brand, p = .75, list = FALSE)
trainingC <-CompleteResponses_New[inTrainingC,]
testingC <-CompleteResponses_New[-inTrainingC,]
fitControlC <-trainControl(method = "repeatedcv", number = 10, repeats = 1)
C5mod <-train(brand~., data = trainingC, method = "C5.0", trControl=fitControlC, tuneLength = 1)
print(C5mod)
varImp(C5mod)
C5modImp <-varImp(C5mod, scale = FALSE)
plot(C5modImp, top = 3)
